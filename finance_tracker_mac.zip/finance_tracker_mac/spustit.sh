#!/bin/bash
echo "📦 Stahuji Docker image z Docker Hubu..."
docker compose pull

echo "🚀 Spouštím aplikaci Finance Tracker..."
docker compose up
